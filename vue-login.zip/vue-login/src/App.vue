<template>
  <main>
    <h1>Login</h1>
    <div class="caixas">
      <input v-model="email" type="text" placeholder="E-mail" required />
    </div>
    <div class="caixas">
      <input v-model="senha" type="password" placeholder="Senha" required />
    </div>
    <p v-if="erroSenha" class="erro">{{ erroSenha }}</p>
    <div class="recuperar-senha">
      <a href="#">Esqueceu sua senha?</a>
    </div>
    <button @click="login" type="button" class="btn_login">Login</button>
    <div class="registro-link">
      <p>
        Não tem uma conta?<br />
        <a href="#">Cadastre-se aqui</a>
      </p>
    </div>
  </main>
</template>

<script setup>
import { ref } from 'vue'

const email = ref('')
const senha = ref('')
const erroSenha = ref('')

function login() {
  if (senha.value.length < 8) {
    erroSenha.value = 'A senha deve ter no mínimo 8 caracteres.'
    return
  }

  erroSenha.value = ''
  console.log('E-mail:', email.value)
  console.log('Senha:', senha.value)
}
</script>

<style>
@import url('https://fonts.googleapis.com/css2?family=M+PLUS+1p&display=swap');

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: "M PLUS 1p", sans-serif;
}

body {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  min-width: 100vw;
  font-weight: 400;
  background-image: url('/img/imagemFundo.jpg');
  background-size: cover;
  background-position: center;
}

main {
  width: 20.625rem;
  background: #FAF7F7;
  padding: 2rem 1rem;
  border-radius: 8px;
  box-shadow: 0 4px 8px rgba(0,0,0,0.1);
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.5rem;
}

main h1 {
  font-weight: 700;
  text-align: center;
  font-size: 1.5rem;
  margin-bottom: 1rem;
}

main .caixas {
  text-align: center;
}

main .caixas input {
  background: #D9D9D9;
  border: none;
  outline: none;
  border-radius: 20px;
  width: 13.34rem;
  height: 2.5rem;
  padding: 1.3rem 3rem 1.3rem 1.3rem;
  font-size: 0.9rem;
}

.caixas input::placeholder {
  color: #5C5454;
}

.erro {
  color: red;
  font-size: 0.8rem;
  margin-top: 0.3rem;
}

.recuperar-senha {
  text-align: center;
  margin-top: 0.5rem;
}

.recuperar-senha a {
  text-decoration: none;
  color: #5C5454;
  font-size: 0.85rem;
  transition: color 0.3s ease;
}

.recuperar-senha a:hover {
  color: #0e0d0d;
  text-decoration: underline;
}

.btn_login {
  background-color: #B3CD8C;
  border: none;
  border-radius: 12px;
  color: #3F3F3F;
  font-size: 1.5rem;
  font-weight: 700;
  width: 13.34rem;
  height: 3.5rem;
  margin-top: 1.5rem;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.btn_login:hover {
  background-color: #a1ba7b;
}

.registro-link {
  text-align: center;
  margin-top: 1rem;
  font-size: 0.9rem;
}

.registro-link a {
  color: #3F3F3F;
  text-decoration: none;
  font-weight: 500;
}

.registro-link a:hover {
  text-decoration: underline;
}
</style>
