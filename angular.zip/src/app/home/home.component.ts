import { Component } from '@angular/core';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-home',
  standalone: true,
  template: `
    <h1>Bem-vindo!</h1>
    <button (click)="logout()">Sair</button>
  `,
  styles: [`
    h1 { color: #6200ee; }
    button { 
      background: #ff0000; 
      color: white;
      padding: 8px 16px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
  `]
})
export class HomeComponent {
  constructor(private authService: AuthService) {}

  logout() {
    this.authService.logout();
  }
}